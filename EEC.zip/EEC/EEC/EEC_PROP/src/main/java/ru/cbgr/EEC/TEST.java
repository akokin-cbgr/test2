package ru.cbgr.EEC;

import java.io.IOException;


public class TEST {

  public static void main(String[] args) throws IOException {
    /*ТЕСТ генерации
    System.out.println(HelperBase.randString("123456789", 4));
    */


    /*ТЕСТ Форматирования
    String test = HelperBase.getFile("src/main/resources/OP_02/FLC/MSG.001_TRN.001/Log/Received_MSG_PRS.xml");
    Document document = XmlStringFormatter.convertStringToDocument(test);
    HelperBase.writeMsgToHdd(XmlStringFormatter.toPrettyXmlString(document),"src/main/resources/OP_02/FLC/MSG.001_TRN.001/Log/Received_MSG_PRS_2.xml");
    */
  }
}
