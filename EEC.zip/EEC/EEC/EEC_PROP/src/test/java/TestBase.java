import ru.cbgr.EEC.HelperBase;


public class TestBase {
  private HelperBase helperBase;


  public HelperBase helperBase() {
    return helperBase;
  }
}