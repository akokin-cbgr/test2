import org.testng.annotations.Test;
import ru.cbgr.EEC.WorkWithXml;

import java.util.NoSuchElementException;

@Test
public class WorkWithXmlTest extends WorkWithXml {
  public void test() throws NoSuchElementException {
  /*  try {
      XMLParser xmlParser = new
      JSONObject jsonObject = new JSONObject(request("eek-test1prop-mg2.tengry.com:27017", "service-prop-65", "radioElectronicDeviceRegistryDetailsType",
              "propositionInclusionRadioElectronicDeviceId","PBY00000000000000204"));
      Assert.assertTrue(jsonObject.get("statusCode").toString().contains("002"));
    }
    catch (NoSuchElementException e){
      System.out.println(e);
    }*/
  }
}
